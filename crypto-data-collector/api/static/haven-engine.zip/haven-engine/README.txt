Haven Engine
============

Runs on your computer and executes your Haven live trades.

FIRST TIME
  1. Install Node.js (LTS) from https://nodejs.org if you don't have it.
  2. Double-click  setup.bat  and follow the prompts:
       - paste your connection key (Haven website -> Settings ->
         "Connect your engine")
       - choose [1] Create a new wallet (default)
       - copy the seed phrase offline, then confirm two words
  3. Double-click  run.bat  to start. Leave the window open.

EVERY TIME AFTER
  Just double-click  run.bat.  Close the window to stop.

IMPORTANT
  - Live trades only run while this program is open and your computer is on.
  - Save your seed phrase. If you lose it, the wallet cannot be recovered.
  - Fund the wallet address printed at the end of setup before live trades.
